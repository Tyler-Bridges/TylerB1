function setup() {
  createCanvas(600, 600);
}

function draw() {
  background("LightSkyBlue");
  fill("rgb(234,234,159)");
  noStroke
  rect(0, 500, 600, 600); //sand
  fill("darkorange");
  triangle(475, 400, 540, 450, 535, 350); //back fin
  fill("orange");
  ellipse(400, 400, 200, 100); //fish body
  fill("white");
  ellipse(350, 380, 20, 20); //eye white
  fill("black");
  ellipse(350, 380, 10, 10); //pupil
  fill("darkorange");
  triangle(380, 400, 430, 420, 437, 380); //side fin
  fill("orange"); // mouth
  arc(313, 400, 40, 40, 70, 360);
  fill("rgb(111,221,111)")
  triangle(220, 200, 280, 220, 280, 155)//f2 back fin
   fill("lightgreen")
  ellipse(200, 200, 100, 50)//f2 body
  fill("white")
  ellipse(175, 190, 10, 10)//f2 eye
  fill("black")
  ellipse(175, 190, 5, 5)//f2 pupil
  fill("lightgreen")
  triangle(190,195, 215, 210, 220, 190)//f2 side fin
}
